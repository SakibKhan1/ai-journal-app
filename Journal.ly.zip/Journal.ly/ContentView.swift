//
//  ContentView.swift
//  Journal.y
//
//  Created by Sakib Khan on 7/15/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
        
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
