import SwiftUI

@main
struct MoodJournalAIApp: App {
    var body: some Scene {
        WindowGroup {
            ChatView()
        }
    }
}

